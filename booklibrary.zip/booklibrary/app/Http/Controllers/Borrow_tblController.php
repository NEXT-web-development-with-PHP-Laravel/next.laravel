<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Borrow_tblController extends Controller
{
    //
}
